#!/usr/bin/env python
# coding: utf-8

# # [Gruppierungen] GroupBy-Objekt

# In[1]:


import pandas as pd
umsatz = pd.read_csv("datengrundlage.xls")


# - Flexible Datenstruktur
# 
# - Es können mehrere Funktionen auf ein Groupby-Objekt angewendet werden
# 
# - Aggregationsfunktionen wie wie sum(), mean() und count() sowie Lambda-Funktionen oder apply()

# In[2]:


umsatz.groupby(by="Land")[["Umsatz"]]


# In[3]:


groupby_object = umsatz.groupby(by="Land")[["Umsatz"]]


# In[4]:


print(type(groupby_object))


# In[7]:


umsatz.groupby(by="Land")[["Umsatz"]].mean().transpose()


# In[ ]:




