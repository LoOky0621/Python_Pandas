#!/usr/bin/env python
# coding: utf-8

# # [Gruppierungen] Daten gruppieren mit GroupBy

# In[1]:


import pandas as pd
umsatz = pd.read_csv("datengrundlage.xls")


# ### Aggregation

# In[3]:


umsatz.Umsatz.agg("mean")


# In[4]:


umsatz.agg({"Umsatz":"mean"})


# ### GroupBy

# In[16]:


umsatz.groupby(by="Land")[["Umsatz"]].mean()


# In[10]:


# pd.DataFrame.groupby?


# ### GroupBy mit agg

# In[15]:


umsatz.groupby(by="Land")[["Umsatz"]].agg("mean")


# ### GroupBy mit aggregate

# In[14]:


umsatz.groupby(by="Land")[["Umsatz"]].aggregate("mean")


# ### Transpose

# In[17]:


umsatz.groupby(by="Land")[["Umsatz"]].aggregate("mean").transpose()


# ### Aggregationsmöglichkeiten

# In[19]:


print("Summe:", umsatz.groupby("Land")[["Umsatz"]].aggregate("sum"))
print("Median:", umsatz.groupby("Land")[["Umsatz"]].aggregate("median"))
print("Quantile:", umsatz.groupby("Land")[["Umsatz"]].aggregate("quantile"))
print("STD", umsatz.groupby("Land")[["Umsatz"]].aggregate("std"))
print("VAR", umsatz.groupby("Land")[["Umsatz"]].aggregate("var"))


# In[ ]:




