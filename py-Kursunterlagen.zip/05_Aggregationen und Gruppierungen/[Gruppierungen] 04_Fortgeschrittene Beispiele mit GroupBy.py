#!/usr/bin/env python
# coding: utf-8

# # [Gruppierungen] Fortgeschrittene Beispiele mit GroupBy

# In[2]:


import pandas as pd
umsatz = pd.read_csv("datengrundlage.xls")


# ## Datengrundlage filtern und gruppieren

# In[4]:


umsatz.head(3)


# ### Mexiko filtern

# In[8]:


umsatz[umsatz.iloc[:, 3] == "Mexiko"]


# In[9]:


mexiko.head()


# #### Welche Städte gibt es?

# In[10]:


mexiko.Stadt.unique()


# ### Mexiko Datengrundlage

# In[11]:


mexiko = umsatz[umsatz.iloc[:, 3] == "Mexiko"]


# ### Gruppierung nach Städten

# In[13]:


mexiko.groupby(by="Stadt").agg({"Umsatz":"mean"}).transpose()


# ### Gruppieren nach mehreren Kategorien

# #### Wie sieht der Median der Kosten aus des Vereinigten Königreichs nach Bereich und Stadt?

# In[16]:


uk = umsatz[umsatz.Land == "Vereinigtes Königreich"]


# In[17]:


uk.head(1)


# In[19]:


uk.groupby(by=["Bereich", "Stadt"]).agg({"Kosten":"median"}).transpose()


# ### Gruppieren nach mehreren numerischen Werten

# #### Wie viele unterschiedliche Ausprägungen von Logistik-Code und Kunde gibt es?

# In[22]:


print(len(umsatz["Logistik-Code"].unique()))
print(len(umsatz["Kunde"].unique()))


# ### Gruppierung nach Kunde für Umsatz (Standardabweichung) und Kosten (Maximum)

# In[23]:


umsatz.groupby(by=["Kunde"]).agg({"Umsatz":"std", "Kosten":"max"})


# In[ ]:




