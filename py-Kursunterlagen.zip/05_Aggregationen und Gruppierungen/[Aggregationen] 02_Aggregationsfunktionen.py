#!/usr/bin/env python
# coding: utf-8

# # [Aggregationen] Aggregationsfunktionen mit Pandas

# In[3]:


import pandas as pd
umsatz = pd.read_csv("datengrundlage.xls")


# ### Describe()-Funktion

# In[4]:


umsatz.describe().transpose()


# ### Aggregationsfunktionen

# - Summe 
# - Anzahl
# - Minimum
# - Maximum
# - Mittelwert
# - Median
# - Quantile
# - Perzentile
# - Standardabweichung
# - Varianz
# - mad (mittlere absolute Abweichung)

# #### Summe

# In[5]:


get_ipython().run_line_magic('pinfo', 'sum')


# In[6]:


sum(umsatz.Umsatz)


# In[7]:


umsatz.Umsatz.sum()


# ### Anzahl

# In[8]:


umsatz.Umsatz.count()


# #### Minimum

# In[9]:


umsatz.Umsatz.min()


# #### Maximum

# In[10]:


umsatz.Umsatz.max()


# #### Mittelwert

# In[11]:


umsatz.Umsatz.mean()


# #### Median

# In[12]:


umsatz.Umsatz.median()


# #### Quantile

# In[13]:


umsatz.Umsatz.quantile(q=[0.25, 0.75])


# #### Perzentile

# In[14]:


umsatz.Umsatz.quantile(q=[0.1, 0.9])


# #### Standardabweichung

# In[15]:


umsatz.Umsatz.std()


# #### Varianz

# In[16]:


umsatz.Umsatz.var()


# ### agg()-/aggregate-Funktion

# In[21]:


umsatz.Umsatz.agg(["sum", "min", "max", "mean", "median", "quantile", "std", "var"])


# In[22]:


umsatz.Umsatz.aggregate(["sum", "min", "max", "mean", "median", "quantile", "std", "var"])


# In[23]:


umsatz.agg({"Umsatz":"mean"})


# In[ ]:




