#!/usr/bin/env python
# coding: utf-8

# # [Gruppierungen] Aufgabe Daten aggregieren und gruppieren

# In[1]:


import pandas as pd
import seaborn as sb


# ### Datengrundlage

# In[2]:


penguins = sb.load_dataset("penguins")


# In[3]:


penguins.head()


# - Bill = Schnabel
# - Flipper = Flügel
# - Body = Körper

# - species (Gattung)	
# - island (Insel)
# - bill_length_mm (Schnabellänge)
# - bill_depth_mm	(Schnabeltiefe)
# - flipper_length_mm	(Schnabellänge)
# - body_mass_g (Körpermasse)	
# - sex (Geschlecht)

# ## 1) Aggregationen

# ### 1.1) Describe()-Funktion

# *Verwende die describe()-Funktion zur Einschätzung der Lageverteilung aller numerischen Variablen*

# In[ ]:





# ### 1.2) Funktionen zur Berechnung

# *Berechne die nachfolgenden Aggregationsfunktionen für die Körpermasse*

# - Summe 
# - Anzahl
# - Minimum
# - Maximum
# - Mittelwert
# - Median
# - 0.25- und 0.75-Quantil
# - 0.15- und 0.85-Perzentil
# - Standardabweichung
# - Varianz
# - mad (mittlere absolute Abweichung)
# 
# *Hinweis: Verwende die print()-Funktion, um die Bezeichnung der jeweiligen Kennzahl als String zusätzlich auszugeben*

# In[ ]:





# ### 1.3) agg- und aggregate-Funktion

# *Verwende nun die agg- und aggregate-Funktion zur Berechnung der Kennzahlen*

# In[ ]:





# ## 2) Gruppierungen

# ### 2.1) GroupBy

# *Erstelle eine Gruppierung, um die durchschnittlichen Flügellängen der Pinguin-Gattungen zu zeigen. Verwende zusätzlich die transpose()-Funktion*

# In[ ]:





# ### 2.2) Filterungen und Gruppierungen

# *Welche Inseln gibt es?*

# In[ ]:





# *Filtere nun die Datenbasis ausschließlich auf "Biscoe". Gruppiere die Biscoe-Datenbasis nun nach dem arithmetischen Mittel von bill_depth_mm und flipper_length_mm*

# In[ ]:





# ## 3) Apply und Lambda

# ### 3.1) Funktionen und Apply

# *Erstelle eine Funktion, welche die Körpermasse in gramm unwandelt in kilogramm. Erstelle anschließend eine Gruppierung nach "species"*

# In[ ]:





# ### 3.2) Lambda und Apply

# *Verwende nun einen Lambda-Ausdruck für die Funktion aus Aufgabe 3.1)*

# In[ ]:




