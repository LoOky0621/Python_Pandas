#!/usr/bin/env python
# coding: utf-8

# # [Aggregationen] Lageverteilung analysieren mit describe

# In[2]:


import pandas as pd
umsatz = pd.read_csv("datengrundlage.xls")


# In[5]:


umsatz.describe().transpose()


# In[11]:


umsatz.describe(percentiles=[0.1, 0.6, 0.9])


# In[12]:


umsatz.dtypes


# In[13]:


import numpy
umsatz.describe(include=[numpy.number])


# In[14]:


umsatz.describe(exclude=[object])


# In[ ]:




