#!/usr/bin/env python
# coding: utf-8

# # [Gruppierungen] Apply und Lambda

# In[1]:


import pandas as pd
umsatz = pd.read_csv("datengrundlage.xls")


# ### Gruppierung

# In[2]:


umsatz.groupby(by="Land")[["Umsatz"]].mean()


# ### Funktion erstellen

# In[3]:


def steuer(x):
    return x * 1.19


# In[5]:


steuer(20)


# ## apply

# In[6]:


umsatz.groupby("Land")[["Umsatz"]].apply(steuer)


# ## Lambda

# In[7]:


steuer2 = lambda x: x*1.19


# In[8]:


umsatz.groupby("Land")[["Umsatz"]].apply(steuer2)


# In[ ]:




