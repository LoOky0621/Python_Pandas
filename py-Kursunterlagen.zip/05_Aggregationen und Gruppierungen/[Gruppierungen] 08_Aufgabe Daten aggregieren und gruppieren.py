#!/usr/bin/env python
# coding: utf-8

# # [Gruppierungen] Lösung Aufgabe Daten aggregieren und gruppieren

# In[1]:


import pandas as pd
import seaborn as sb


# ### Datengrundlage

# In[2]:


penguins = sb.load_dataset("penguins")


# In[3]:


penguins.head()


# - Bill = Schnabel
# - Flipper = Flügel
# - Body = Körper

# - species (Gattung)	
# - island (Insel)
# - bill_length_mm (Schnabellänge)
# - bill_depth_mm	(Schnabeltiefe)
# - flipper_length_mm	(Schnabellänge)
# - body_mass_g (Körpermasse)	
# - sex (Geschlecht)

# ## 1) Aggregationen

# ### 1.1) Describe()-Funktion

# *Verwende die describe()-Funktion zur Einschätzung der Lageverteilung aller numerischen Variablen*

# In[5]:


penguins.describe().transpose()


# In[7]:


penguins.dtypes


# In[9]:


print(len(penguins.columns))


# In[10]:


penguins.iloc[:, 2:len(penguins.columns)-1].describe().transpose()


# ### 1.2) Funktionen zur Berechnung

# *Berechne die nachfolgenden Aggregationsfunktionen für die Körpermasse*

# - Summe 
# - Anzahl
# - Minimum
# - Maximum
# - Mittelwert
# - Median
# - 0.25- und 0.75-Quantil
# - 0.15- und 0.85-Perzentil
# - Standardabweichung
# - Varianz
# - mad (mittlere absolute Abweichung)
# 
# *Hinweis: Verwende die print()-Funktion, um die Bezeichnung der jeweiligen Kennzahl als String zusätzlich auszugeben*

# In[17]:


print("Summe:", penguins.body_mass_g.sum())
print("Anzahl:", penguins.body_mass_g.count())
print("Minimum:", penguins.body_mass_g.min())
print("Maximum:", penguins.body_mass_g.max())
print("Mittelwert:", penguins.body_mass_g.mean())
print("Median:", penguins.body_mass_g.median())
print("Quantile:", penguins.body_mass_g.quantile(q=[0.25, 0.75]))
print("Perzentile:", penguins.body_mass_g.quantile(q=[0.15, 0.85]))
print("Standardabweichung:", penguins.body_mass_g.std())
print("Varianz:", penguins.body_mass_g.var())


# ### 1.3) agg- und aggregate-Funktion

# *Verwende nun die agg- und aggregate-Funktion zur Berechnung der Kennzahlen*

# In[18]:


penguins.body_mass_g.agg(["sum", "count", "min", "max", "mean", "median", "quantile", "std", "var"])


# ## 2) Gruppierungen

# ### 2.1) GroupBy

# *Erstelle eine Gruppierung, um die durchschnittlichen Mittelwerte der Pinguin-Gattungen zu zeigen. Verwende zusätzlich die transpose()-Funktion*
# 
# Variable: flipper_length

# In[19]:


penguins.groupby(by="species")[["flipper_length_mm"]].mean().transpose()


# In[20]:


penguins.groupby(by="species")[["flipper_length_mm"]].aggregate("mean").transpose()


# In[21]:


penguins.groupby(by="species")[["flipper_length_mm"]].agg("mean").transpose()


# ### 2.2) Filterungen und Gruppierungen

# *Welche Inseln gibt es?*

# In[23]:


penguins.island.unique()


# *Filtere nun die Datenbasis ausschließlich auf "Biscoe". Gruppiere die Biscoe-Datenbasis nun nach dem arithmetischen Mittel von bill_depth_mm und flipper_length_mm*

# In[24]:


biscoe = penguins[penguins.island == "Biscoe"]


# In[25]:


biscoe.head()


# In[26]:


biscoe.groupby(by="species").agg({"bill_depth_mm":"mean", "flipper_length_mm":"mean"})


# ## 3) Apply und Lambda

# ### 3.1) Funktionen und Apply

# *Erstelle eine Funktion, welche die Körpermasse in gramm unwandelt in kilogramm*

# In[27]:


def conversion(x):
    return x / 1000


# In[28]:


penguins.groupby(by="species")[["body_mass_g"]].apply(conversion)


# ### 3.2) Lambda und Apply

# *Verwende nun einen Lambda-Ausdruck für die Funktion aus Aufgabe 3.1)*

# In[30]:


conversion2 = lambda x: x / 1000


# In[31]:


penguins.groupby(by="species")[["body_mass_g"]].apply(conversion2)


# In[ ]:




