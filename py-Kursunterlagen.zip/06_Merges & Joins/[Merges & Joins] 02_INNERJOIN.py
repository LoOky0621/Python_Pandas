#!/usr/bin/env python
# coding: utf-8

# # [Merges & Joins] INNERJOIN

# In[1]:


import pandas as pd


# ## Beispiel: Erstellte DataFrames

# In[3]:


planeten1 = pd.DataFrame([['merkur', 222], ['neptun', 4687], ['mars', 401]],
                   columns=['Planet', 'Entfernung zur Erde in Mio. km'])

planeten2 = pd.DataFrame([['venus', 261], ['uranus', 3157], ['pluto', 7528]],
                   columns=['Planet', 'Entfernung zur Erde in Mio. km'])


# In[4]:


pd.concat([planeten1, planeten2], join="inner")


# In[6]:


# pd.DataFrame.merge?


# ## Innerjoin mit eingelesenen Daten

# In[10]:


fertigung = pd.read_excel("fertigung.xlsx")
produkt = pd.read_excel("produkt.xlsx")


# In[17]:


fertigung


# In[16]:


produkt


# In[14]:


pd.merge(fertigung, produkt)


# #### on-Parameter

# In[13]:


pd.merge(fertigung, produkt, on="Produkt-ID")


# #### how-Parameter

# In[15]:


pd.merge(fertigung, produkt, on="Produkt-ID", how="inner")


# ### Alternative Schreibweise

# In[18]:


fertigung.merge(produkt, on="Produkt-ID", how="inner")


# In[19]:


produkt.merge(fertigung, on="Produkt-ID", how="inner")


# In[ ]:




