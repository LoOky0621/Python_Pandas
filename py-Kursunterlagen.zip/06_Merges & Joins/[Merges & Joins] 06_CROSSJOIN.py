#!/usr/bin/env python
# coding: utf-8

# # [Merges & Joins] CROSSJOIN

# *Ein Cross-Join gibt alle möglichen Zeilenkombinationen aus zwei Tabellen zurück*

# In[1]:


import pandas as pd


# In[2]:


fertigung = pd.read_excel("fertigung.xlsx")
produkt = pd.read_excel("produkt.xlsx")


# In[3]:


fertigung


# In[4]:


produkt


# In[5]:


fertigung["hilfsspalte"] = "A"


# In[6]:


fertigung


# In[7]:


produkt["hilfsspalte"] = "A"


# In[8]:


produkt


# In[9]:


pd.merge(fertigung, produkt, on="hilfsspalte", how="outer")


# In[ ]:




