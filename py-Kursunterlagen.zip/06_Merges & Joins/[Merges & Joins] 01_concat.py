#!/usr/bin/env python
# coding: utf-8

# # [Merges & Joins] Daten einfach verknüpfen über concat

# In[3]:


import pandas as pd


# ## Series verknüpfen

# In[5]:


series1 = pd.Series(["merkur", "neptun", "mars"])
series2 = pd.Series(["venus", "uranus", "pluto"])


# In[7]:


series3 = pd.concat([series1, series2])


# In[8]:


series3


# In[10]:


pd.concat([series1, series2], keys=["series1", "series2"], names=["Gruppe 1", "Gruppe 2"])


# ## DataFrames verknüpfen

# In[12]:


planeten1 = pd.DataFrame(data=[["merkur", 222], ["neptun", 4676], ["mars", 401]], 
                        columns = ["Planet", "Entfernung zur Erde in Mio. km"])

planeten2 = pd.DataFrame(data=[["venus", 261], ["uranus", 3157], ["pluto", 7528]], 
                        columns = ["Planet", "Entfernung zur Erde in Mio. km"])


# In[14]:


print(planeten1)
print(planeten2)


# In[15]:


pd.concat([planeten1, planeten2])


# In[16]:


pd.concat([planeten1, planeten2], join="inner")


# In[ ]:




