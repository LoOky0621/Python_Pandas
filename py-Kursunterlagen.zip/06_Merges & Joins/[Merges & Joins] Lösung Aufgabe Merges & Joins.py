#!/usr/bin/env python
# coding: utf-8

# # [Merges & Joins] Lösung Aufgabe Merges & Joins

# In[2]:


import pandas as pd


# ## 1) Daten einlesen

# *Gegeben sind die Excel-Dateien "Umsatz.xlsx" und "Kunden.xlsx". Verwende Pandas, um die Daten einzulesen und als DataFrames zu speichern*

# In[3]:


umsatz = pd.read_excel("Umsatz.xlsx")
kunden = pd.read_excel("Kunden.xlsx")


# In[6]:


umsatz


# In[7]:


kunden


# ## 2) INNERJOIN

# *Nutze einen Innerjoin, um die Daten zu verbinden. Wie viele Datensätze liegen vor?*

# In[8]:


pd.merge(umsatz, kunden)


# In[9]:


pd.merge(umsatz, kunden, on="Kunden-ID", how="inner")


# In[11]:


# umsatz.merge(kunden, on="Kunden-ID", how="inner")


# ## 3) OUTERJOIN

# *Setze nun einen Outerjoin ein*

# In[12]:


pd.merge(umsatz, kunden, on="Kunden-ID", how="outer")


# In[14]:


# umsatz.merge(kunden, on="Kunden-ID", how="outer")


# ## 4) LEFTJOIN

# *Verwende nun einen Leftjoin*

# In[15]:


pd.merge(umsatz, kunden, on="Kunden-ID", how="left")


# In[18]:


# umsatz.merge(kunden, on="Kunden-ID", how="left")


# In[16]:


kunden.tail()


# ## 5) RIGHTJOIN

# *Wie viele Einträge liegen bei einem Rightjoin vor?*

# In[19]:


pd.merge(umsatz, kunden, on="Kunden-ID", how="right")


# In[20]:


umsatz.merge(kunden, on="Kunden-ID", how="right")


# ## ANTI-JOINS

# In[21]:


outer = pd.merge(umsatz, kunden, how="outer", indicator=True)


# In[25]:


# outer


# ## 6) LEFT-ANTIJOIN

# *Verwende nun einen Left-Antijoin*

# In[26]:


outer[(outer._merge == "left_only")].drop("_merge", axis=1)


# ## 7) RIGHT-ANTIJOIN

# *Verwende nun einen Right-Antijoin*

# In[27]:


outer[(outer._merge == "right_only")].drop("_merge", axis=1)


# In[ ]:




