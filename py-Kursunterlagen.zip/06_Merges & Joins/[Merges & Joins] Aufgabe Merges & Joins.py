#!/usr/bin/env python
# coding: utf-8

# # [Merges & Joins] Aufgabe Merges & Joins

# In[14]:


import pandas as pd


# ## 1) Daten einlesen

# *Gegeben sind die Excel-Dateien "Umsatz.xlsx" und "Kunden.xlsx". Verwende Pandas, um die Daten einzulesen und als DataFrames zu speichern*

# In[ ]:





# ## 2) INNERJOIN

# *Nutze einen Innerjoin, um die Daten zu verbinden. Wie viele Datensätze liegen vor?*

# In[ ]:





# ## 3) OUTERJOIN

# *Setze nun einen Outerjoin ein*

# In[ ]:





# ## 4) LEFTJOIN

# *Verwende nun einen Leftjoin*

# In[ ]:





# ## 5) RIGHTJOIN

# *Wie viele Einträge liegen bei einem Rightjoin vor?*

# In[ ]:





# ## 6) LEFT-ANTIJOIN

# *Verwende nun einen Left-Antijoin*

# In[ ]:





# ## 7) RIGHT-ANTIJOIN

# *Verwende nun einen Right-Antijoin*

# In[ ]:




