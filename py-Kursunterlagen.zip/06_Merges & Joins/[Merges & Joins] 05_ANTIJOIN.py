#!/usr/bin/env python
# coding: utf-8

# # [Merges & Joins] ANTIJOIN

# In[13]:


import pandas as pd


# In[14]:


fertigung = pd.read_excel("fertigung.xlsx")
produkt = pd.read_excel("produkt.xlsx")


# In[15]:


fertigung


# In[16]:


produkt


# ### LEFTJOIN

# In[17]:


pd.merge(fertigung, produkt, on="Produkt-ID", how="left")


# ### RIGHTJOIN

# In[18]:


pd.merge(fertigung, produkt, on="Produkt-ID", how="right")


# ## LEFT ANTI JOIN

# In[19]:


outerjoin = pd.merge(fertigung, produkt, how="outer", on="Produkt-ID", indicator=True)


# In[20]:


outerjoin


# In[25]:


outerjoin[outerjoin._merge == "left_only"].drop("_merge", axis=1)


# ## RIGHT ANTI JOIN

# In[26]:


outerjoin[outerjoin._merge == "right_only"].drop("_merge", axis=1)


# In[ ]:




