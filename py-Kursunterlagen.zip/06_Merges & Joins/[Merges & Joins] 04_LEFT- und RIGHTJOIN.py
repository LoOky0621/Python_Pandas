#!/usr/bin/env python
# coding: utf-8

# # [Merges & Joins] LEFT- und RIGHTJOIN

# In[1]:


import pandas as pd


# In[2]:


fertigung = pd.read_excel("fertigung.xlsx")
produkt = pd.read_excel("produkt.xlsx")


# In[3]:


fertigung


# In[4]:


produkt


# ## Left-Join

# In[5]:


pd.merge(fertigung, produkt, on="Produkt-ID", how="left")


# #### Alternative Schreibweise

# In[6]:


fertigung.merge(produkt, on="Produkt-ID", how="left")


# ## Right-Join

# In[7]:


pd.merge(fertigung, produkt, on="Produkt-ID", how="right")


# #### Alternative Schreibweise

# In[10]:


# fertigung.merge(produkt, on="Produkt-ID", how="right")


# In[8]:


produkt.merge(fertigung, on="Produkt-ID", how="right")


# In[ ]:




