#!/usr/bin/env python
# coding: utf-8

# # [Merges & Joins] OUTERJOIN

# In[1]:


import pandas as pd


# In[3]:


fertigung = pd.read_excel("fertigung.xlsx")
produkt = pd.read_excel("produkt.xlsx")


# In[5]:


fertigung


# In[6]:


produkt


# In[7]:


pd.merge(fertigung, produkt, on="Produkt-ID", how="outer")


# ### Alternative Schreibweise

# In[8]:


fertigung.merge(produkt, on="Produkt-ID", how="outer")


# In[9]:


produkt.merge(fertigung, on="Produkt-ID", how="outer")


# In[ ]:




