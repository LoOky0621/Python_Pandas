#!/usr/bin/env python
# coding: utf-8

# # [Indexing] Aufgabe Indexing

# In[3]:


import pandas as pd


# In[4]:


kunden = pd.read_excel("Kunden.xlsx")


# In[5]:


kunden


# ## Aufgabe 1: "iloc"-Filterung

# ### 1.1) Erste Zeile (Index = 0)

# In[ ]:





# ### 1.2) Zweite Zeile (Index = 1)

# In[ ]:





# ### 1.3) Letzte Zeile

# In[ ]:





# ### 1.4) Vierte Spalte und alle Zeilen

# In[ ]:





# ### 1.5) Letzte Spalte

# In[ ]:





# ### 1.6) Nur die Spalten "Land", "Postleitzahl" und "Stadt"

# In[ ]:





# ### 1.7) Nur die Spalten "Kunde", "Land" und "Stadt"

# In[ ]:





# ## Aufgabe 2: "loc"-Filterung

# ### 2.1) Alle Einträge

# In[ ]:





# ### 2.2) Nur die erste Zeile (Index=0)

# In[ ]:





# ### 2.3) Nur die ersten 7 Zeilen (Index=0-6)

# In[ ]:





# ### 2.4) Kunde als Index setzen

# In[ ]:





# ### 2.5) Nur Zeilen mit Kunden "FSA-L SAS", "Hegman, Sas." und "Herfs Inc."

# In[ ]:





# ### 2.6) Nur Spalten "Land", "Stadt" und "Straße" für Kunden "Jungmann Kft.	"

# In[ ]:




