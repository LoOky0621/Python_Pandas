#!/usr/bin/env python
# coding: utf-8

# # [Indexing] loc- Labelbezogen

# In[4]:


import pandas as pd


# In[5]:


umsatz = pd.read_csv("datengrundlage.xls")


# ### Logik

# In[ ]:


umsatz.loc[zeilenbezeichnung, spaltenbezeichnung]


# ### Alle Einträge

# In[6]:


umsatz.loc[:,:]


# ### Nur die erste Zeile (Index=0)

# In[7]:


umsatz.loc[0,:]


# ### Nur die ersten 5 Zeilen (Index=0-4)

# In[8]:


umsatz.loc[0:4, :]


# ### Nur ausgewählte Zeilen

# In[9]:


umsatz.loc[[0, 4, 10, 55, 77], :]


# ### Nur die Spalte "Land"

# In[10]:


umsatz.loc[:, "Land"]


# In[15]:


len(umsatz) - 1


# In[16]:


umsatz.loc[0:len(umsatz)-1, "Land"]


# ### Nur die ersten 5 Einträge der Spalte "Land"

# In[11]:


umsatz.loc[0:5, "Land"]


# ### Nur ausgewählte Spalten

# In[18]:


umsatz.loc[0:10, ["Datum", "Umsatz", "Kosten"]]


# ### Nur ausgewählte Spalten und Zeilen

# In[20]:


umsatz_neu = umsatz.loc[[0, 4, 5, 7, 9], ["Datum", "Stadt", "Umsatz", "Land"]]


# In[21]:


# umsatz.neu.to_csv("beispiel.csv")


# ### Neuer Index

# In[22]:


umsatz.head(3)


# In[25]:


umsatz = umsatz.set_index(["Datum"])


# In[26]:


umsatz


# ### Indexing mit Datum

# In[27]:


umsatz.loc["1/1/2025":"1/10/2025", :]


# ### Indexing mit Strings

# In[28]:


# Umsatz, Marktkapitalisierung, Ergebnis
tech = pd.DataFrame({'AAPL': [395, 2390, 100], 
                   'GOOG': [280, 1240, 60], 
                  'AMZ' : [514, 960, 14]}, 
                   index = ["umsatz", "marktkapitalisierung", "ergebnis"])


# In[29]:


tech


# In[30]:


tech.loc["marktkapitalisierung", :]


# In[31]:


tech.loc[["marktkapitalisierung", "ergebnis"], "AMZ"]


# In[32]:


tech.transpose()


# In[ ]:




