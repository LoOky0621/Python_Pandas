#!/usr/bin/env python
# coding: utf-8

# # [Indexing] iloc - Indexbezogen

# In[1]:


import pandas as pd


# In[2]:


umsatz = pd.read_csv("datengrundlage.xls")


# In[3]:


umsatz.head()


# ### Logik

# In[5]:


# pd.DataFrame.iloc[zeilen, spalten]


# ### Erste Zeile (Index = 0)

# In[6]:


umsatz.iloc[0]


# ### Zweite Zeile (Index = 1)

# In[7]:


umsatz.iloc[1]


# ### Letzte Zeile

# In[9]:


umsatz.iloc[1379]


# In[12]:


umsatz.iloc[len(umsatz) - 1]


# ### Mehrere Einträge

# In[16]:


umsatz.iloc[0:5]


# In[15]:


umsatz.head()


# In[17]:


n = len(umsatz)


# In[18]:


umsatz.iloc[n-6:n-1]


# In[19]:


umsatz.tail()


# ### Dritte Spalte und alle Zeilen

# In[ ]:


# umsatz.iloc[zeilen, spalten]


# In[24]:


umsatz.iloc[:,2]


# ### Letzte Spalte

# In[28]:


umsatz.iloc[:, 11]


# In[29]:


umsatz.columns


# In[31]:


ncol = len(umsatz.columns)
print(ncol)


# In[32]:


umsatz.iloc[:, ncol-1]


# ### Mehrere Spalten

# In[34]:


umsatz.head(1)


# In[35]:


umsatz.iloc[:, 5:ncol]


# ### Nur ausgewählte Spalten

# In[36]:


umsatz.iloc[:, [0, 4, ncol-1]]


# ### Ausgewähltes Element

# In[37]:


umsatz.iloc[[0, 3, 6, 204], [0, 4, ncol-1]]


# In[ ]:




