#!/usr/bin/env python
# coding: utf-8

# # [Indexing] Lösung Aufgabe Indexing

# In[3]:


import pandas as pd


# In[4]:


kunden = pd.read_excel("Kunden.xlsx")


# In[6]:


# kunden


# ## Aufgabe 1: "iloc"-Filterung

# In[7]:


# kunden.iloc[zeilenindex, spaltenindex]


# ### 1.1) Erste Zeile (Index = 0)

# In[11]:


kunden.head(2)


# In[10]:


kunden.iloc[0,:]


# ### 1.2) Zweite Zeile (Index = 1)

# In[12]:


kunden.iloc[1,:]


# ### 1.3) Letzte Zeile

# In[14]:


kunden.tail(1)


# In[15]:


kunden.iloc[29,:]


# In[16]:


len(kunden)


# In[17]:


kunden.iloc[len(kunden)-1, :]


# In[18]:


n = len(kunden)-1
kunden.iloc[n, :]


# ### 1.4) Vierte Spalte und alle Zeilen

# In[20]:


# kunden.iloc[:,3]


# ### 1.5) Letzte Spalte

# In[21]:


kunden.head(1)


# In[22]:


kunden.iloc[:,6]


# In[24]:


len(kunden.columns)


# In[25]:


kunden.iloc[:, len(kunden.columns)-1]


# ### 1.6) Nur die Spalten "Land", "Postleitzahl" und "Stadt"

# In[26]:


kunden.head(1)


# In[27]:


kunden.iloc[:, [3, 4, 5]]


# In[29]:


kunden.iloc[:, 3:6]


# ### 1.7) Nur die Spalten "Kunde", "Land" und "Stadt"

# In[33]:


kunden.iloc[:, [1, 3, 5]]


# ## Aufgabe 2: "loc"-Filterung

# In[34]:


# kunden.loc[zeilen, spalten]


# ### 2.1) Alle Einträge

# In[37]:


kunden.loc[:]


# ### 2.2) Nur die erste Zeile (Index=0)

# In[39]:


kunden.loc[0, :]


# ### 2.3) Nur die ersten 7 Zeilen (Index=0-6)

# In[41]:


kunden.loc[0:6, :]


# ### 2.4) Kunde als Index setzen

# In[45]:


kunden = kunden.set_index("Kunde")


# ### 2.5) Nur Zeilen mit Kunden "FSA-L SAS", "Hegman, Sas." und "Herfs Inc."

# In[46]:


kunden.loc[["FSA-L SAS", "Hegman, Sas.", "Herfs Inc."], :]


# ### 2.6) Nur Spalten "Land", "Stadt" und "Straße" für Kunden "Jungmann Kft.	"

# In[47]:


kunden.loc["Jungmann Kft.", ["Land", "Stadt","Straße"]]


# In[ ]:




