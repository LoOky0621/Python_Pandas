#!/usr/bin/env python
# coding: utf-8

# # [Einführung Pandas] Pandas DataFrame

# In[1]:


import pandas as pd


# ## Von Series zu DataFrame

# In[2]:


# Angabe Umsatz, Ergebnis und Börsenwert in Mrd. EUR zum Fiskaljahr 2022


# In[3]:


airbus = pd.Series([59,5.2,101, 134267], 
                   index=["umsatz", "ergebnis", "börsenwert", "mitarbeiter"], 
                   name="Airbus")


boeing = pd.Series([66,-3.5,114, 156000], 
                   index=["umsatz", "ergebnis", "börsenwert", "mitarbeiter"], 
                   name="Boeing")


# In[4]:


print(airbus)
print(boeing)


# In[5]:


print(type(airbus))
print(type(boeing))


# ### Umwandlung

# In[8]:


print(type(pd.concat([airbus, boeing])))


# In[11]:


airbus_boeing_df = pd.merge(airbus, boeing, right_index=True, left_index=True)


# In[12]:


print(airbus_boeing_df)


# In[13]:


airbus_boeing_df


# In[14]:


print(type(airbus_boeing_df))


# ## DataFrame erstellen

# In[16]:


pd.DataFrame(data = [100, 200, 300, 400])


# In[17]:


pd.DataFrame(data = [100, 200, 300, 400], index = ["index1", "index2", "index3", "index4"])


# In[18]:


pd.DataFrame(data = {"überschrift1":[100, 200, 300, 400]}, index = ["index1", "index2", "index3", "index4"])


# ### Beispiel: Airbus und Boeing

# In[31]:


airbus_boeing_df.transpose()


# In[29]:


pd.DataFrame([airbus, boeing]).transpose()


# In[30]:


pd.DataFrame(data = {"airbus" : [59, 5.2, 101, 134267], 
                    "boeing" : [66, -3.5, 114, 156000]}, 
             index = ["umsatz", "ergebnis", "börsenwert", "mitarbeiter"]).transpose()


# In[ ]:




