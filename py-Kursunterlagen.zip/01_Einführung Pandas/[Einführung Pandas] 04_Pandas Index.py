#!/usr/bin/env python
# coding: utf-8

# # [Einführung Pandas] Pandas Index

# In[5]:


import pandas as pd


# - unveränderliche Datenstruktur
# 
# - Basisobjekt, welches die Achsenbeschriftungen für alle Pandas-Objekte speichert

# In[7]:


# pd.Index?


# ### Index: Integer

# In[9]:


pd.Index([100, 200, 300], dtype="int32")


# ### Index: Floats

# In[11]:


pd.Index([100.1, 200.2, 300.3], dtype="float32")


# ### Index: Strings

# In[12]:


pd.Index(["1", "2", "3"], dtype="object")


# ### Index: Booleans

# In[13]:


pd.Index([True, False, True, True, False], dtype="bool")


# In[14]:


type(pd.Index([100, 200, 300], dtype="int32"))


# In[15]:


pd.Index([100, 200, 300], dtype="int32").dtype


# In[16]:


pd.Index([100.1, 200.2, 300.3], dtype="float32").dtype


# In[18]:


pd.Index([True, False, True, True, False], dtype="bool").dtype


# In[ ]:




