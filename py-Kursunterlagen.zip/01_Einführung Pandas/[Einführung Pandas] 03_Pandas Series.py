#!/usr/bin/env python
# coding: utf-8

# # [Einführung Pandas] Pandas Series

# In[1]:


import pandas as pd


# ## 1) Series Grundlagen

# ### Series mit Zahlenwerten

# In[4]:


series1 = pd.Series(data = [0.1, 0.3, 0.5, 0.6, 0.8])


# In[5]:


series2 = pd.Series(data = [1, 3, 5, 6, 8])


# ### Series mit Zeichenketten

# In[6]:


series3 = pd.Series(data = ["rot", "gelb", "blau", "grün", "braun"])


# ### Series mit unterschiedlichen Datentypen

# In[7]:


series4 = pd.Series(data = ["blau", 3, 3.1, True, False])


# In[8]:


series4


# ## 2) Series aus Dictionary

# In[9]:


# Einwohnerzahlen von europ. Städten
dict1 = {"rom" : 2.8, "paris" : 2.1, "berlin" : 3.8, "wien" : 2.0}


# In[11]:


type(dict1)


# In[12]:


series5 = pd.Series(dict1)


# In[13]:


series5


# In[14]:


type(series5)


# ## 3) Index bei Series

# In[17]:


series5 = pd.Series(dict1, index = ["berlin", "rom", "paris", "wien"])


# ### Weiteres Beispiel

# In[20]:


pd.Series(["blau", "rot", "gelb", "braun"], index = [1, 2, 3, 4])


# In[ ]:




