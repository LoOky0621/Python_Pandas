#!/usr/bin/env python
# coding: utf-8

# # [Einführung Pandas] Aufgabe Pandas Grundlagen

# In[1]:


import pandas as pd


# # Aufgabe 1: Pandas-Series

# ### 1.1) Series aus Liste

# *Gegeben ist die Liste mit den Weltrekorden im Hochsprung. Erstelle daraus eine Series und überprüfe den Type*

# In[2]:


hochsprung = [2.45, 2.44, 2.43, 2.42, 2.41]


# In[ ]:





# ### 1.2) Series und Index

# *Gegeben ist nun auch die Liste der Athleten zu den Rekorden. Erstelle daraus einen Index für die Series*

# In[3]:


rekorde = ["Javier Sotomayor", "Javier Sotomayor", "Javier Sotomayor", "Carlo Thränhardt", "Igor Paklin"]


# In[ ]:





# # Aufgabe 2: Pandas-Index

# ### 2.1) Index-Erstellung

# *Erstelle aus der Liste "athleten" nun ein Pandas-Index mit der Bezeichnung "index_athleten"*

# In[ ]:





# ### 2.2) Index und Series

# *Füge den Index nun der Series hinzu*

# In[ ]:





# # Aufgabe 3: Pandas-DataFrame

# ### 3.1) DataFrame erstellen

# *Erstelle nun auch ein DataFrame aus den obigen Daten und nenne die Spalte "Rekorde"*

# In[ ]:





# ### 3.2) Datentyp überprüfen

# *Überprüfe nun final auch den Datentypen des DataFrames*

# In[ ]:




