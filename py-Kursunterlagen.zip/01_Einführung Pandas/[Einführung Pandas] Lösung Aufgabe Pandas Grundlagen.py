#!/usr/bin/env python
# coding: utf-8

# # [Einführung Pandas] Lösung Aufgabe Pandas Grundlagen

# In[3]:


import pandas as pd


# # Aufgabe 1: Pandas-Series

# ### 1.1) Series aus Liste

# *Gegeben ist die Liste mit den Weltrekorden im Hochsprung. Erstelle daraus eine Series und überprüfe den Type*

# In[4]:


hochsprung = [2.45, 2.44, 2.43, 2.42, 2.41]


# In[5]:


print(type(hochsprung))


# In[8]:


hochsprung_series = pd.Series([hochsprung])


# In[9]:


print(type(hochsprung_series))


# ### 1.2) Series und Index

# *Gegeben ist nun auch die Liste der Athleten zu den Rekorden. Erstelle daraus einen Index für die Series*

# In[16]:


rekorde = ["Javier Sotomayor", "Javier Sotomayor", "Javier Sotomayor", "Carlo Thränhardt", "Igor Paklin"]


# In[12]:


series_final = pd.Series(hochsprung, index=rekorde)


# In[13]:


series_final


# # Aufgabe 2: Pandas-Index

# ### 2.1) Index-Erstellung

# *Erstelle aus der Liste "athleten" nun ein Pandas-Index mit der Bezeichnung "index_athleten"*

# In[18]:


index_athleten = pd.Index(rekorde)


# ### 2.2) Index und Series

# *Füge den Index nun der Series hinzu*

# In[20]:


series_index = pd.Series(hochsprung, index = index_athleten)


# In[21]:


series_index


# In[22]:


print(type(series_index))


# # Aufgabe 3: Pandas-DataFrame

# ### 3.1) DataFrame erstellen

# *Erstelle nun auch ein DataFrame aus den obigen Daten und nenne die Spalte "Rekorde"*

# In[28]:


dataframe_hochsprung = pd.DataFrame(hochsprung, index=index_athleten, columns=["Rekorde in m"])


# ### 3.2) Datentyp überprüfen

# *Überprüfe nun final auch den Datentypen des DataFrames*

# In[29]:


dataframe_hochsprung


# In[30]:


print(type(dataframe_hochsprung))


# In[ ]:




