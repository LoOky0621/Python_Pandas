#!/usr/bin/env python
# coding: utf-8

# # [Einführung Pandas] Pandas Objekte

# In[1]:


import pandas as pd


# In[3]:


# ?pd


# ## 1) Pandas-Index

# - Unveränderliches Array
# 
# - Grundlegende Datenstruktur, welche Achsenbeschriftungen für alle Pandas-Objekte speichert

# In[5]:


pd.Index([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])


# In[6]:


index1 = pd.Index([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])


# In[7]:


index1


# In[9]:


type(index1)


# ## 2) Pandas-Series

# - Eindimensionales Array mit Index
# - Wie eine Spalte

# In[11]:


pd.Series([0, 0.1, 0.3, 0.5, 0.6, 0.8, 1])


# In[12]:


series1 = pd.Series([0, 0.1, 0.3, 0.5, 0.6, 0.8, 1])


# In[13]:


type(series1)


# ## 3) Pandas-DataFrame

# - "Datentabelle"
# - Ähnlich wie ein zweidimensionales Array
# - Beschriftete Achsen mit Zeilen und Spalten
# - Ideal zum Verarbeiten von Daten

# In[15]:


pd.DataFrame([2024, 2025, 2026])


# In[18]:


data1 = pd.DataFrame({"Jahre":[2024, 2025, 2026]})


# In[19]:


data1


# In[20]:


print(data1)


# In[21]:


type(data1)


# In[ ]:




