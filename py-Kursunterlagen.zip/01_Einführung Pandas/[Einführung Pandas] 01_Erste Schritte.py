#!/usr/bin/env python
# coding: utf-8

# # [Einführung Pandas] Erste Schritte

# In[5]:


import pandas as pd


# In[2]:


get_ipython().system('pip install pandas')


# In[3]:


# conda install pandas


# In[4]:


pd.__version__


# In[6]:


get_ipython().system('pip install -U pandas')


# In[2]:


pd.__version__


# In[6]:


# Möglichkeit 1: "?"
get_ipython().run_line_magic('pinfo', 'pd.concat')


# In[ ]:


# Möglichkeit 1: "SHIFT + TAB"
pandas.concat()

