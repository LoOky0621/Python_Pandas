#!/usr/bin/env python
# coding: utf-8

# # [Pandas Visualisierungen] Histogramm

# In[1]:


import pandas as pd
from matplotlib import pyplot as plt


# In[2]:


umsatz = pd.read_csv("datengrundlage.xls")


# ## Histogramm visualisieren

# ### Variante 1

# In[4]:


umsatz.dtypes


# In[3]:


umsatz.hist()


# In[6]:


umsatz.Umsatz.hist()


# In[7]:


umsatz.hist(column="Umsatz")


# ### Variante 2

# In[9]:


umsatz.Umsatz.plot(kind="hist")


# ### bins-Parameter

# In[11]:


umsatz.hist("Umsatz", bins=50, color="orange")


# ### Mehrere Datenreihen

# In[12]:


umsatz[["Kosten", "Umsatz"]].plot(kind="hist", bins=50)


# In[13]:


umsatz.hist(column=["Kosten", "Umsatz"])


# ### Kategorische Aufteilung

# In[14]:


umsatz.hist(column = "Umsatz", by="Land")


# ### Filterungen

# In[18]:


umsatz[umsatz.Land == "Deutschland"].hist(column="Umsatz", by="Stadt")


# In[ ]:




