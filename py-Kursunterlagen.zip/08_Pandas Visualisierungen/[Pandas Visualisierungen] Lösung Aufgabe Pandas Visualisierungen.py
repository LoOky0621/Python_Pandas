#!/usr/bin/env python
# coding: utf-8

# # [Pandas Visualisierungen] Weitere Visualisierungstypen

# In[1]:


import pandas as pd
import seaborn as sb


# In[2]:


sb.get_dataset_names()


# ### glue-Datensatz

# **General Language Understanding Evaluation**
# 
# - Natural Language Understanding
# 
# - Plattform zur Bewertung und Analyse von NLP- und NLU-Modellen

# In[3]:


glue = sb.load_dataset("glue")
glue


# ### Sprachverständnisaufgaben

# In[17]:


glue.Task.unique()


# 1. CoLA (Corpus of Linguistic Acceptability)
# 2. MRPC (Microsoft Research Paraphrase Corpus)
# 3. SST-2 (Stanford Sentiment Treebank)
# 4. QQP (Quora Question Pairs)
# 5. STS-B (Semantic Textual Similarity Benchmark)
# 6. MNLI (Multi-Genre Natural Language Inference)
# 7. QNLI (Question NLI)
# 8. WNLI (Winograd NLI)
# 9. RTE (Recognizing Textual Entailment)

# ## 1. Linien- und Flächendiagramm

# *Visualisiere den Score in einem Linien- und Flächendiagramm. Füge Diagrammbeschriftung und Achsenbeschriftungen hinzu. Verwende die Farbe "orange"*

# In[6]:


glue["Score"].plot(title="Liniendiagramm", xlabel="Verlauf", ylabel="Score", color="orange")


# In[7]:


glue["Score"].plot.line(title="Liniendiagramm", xlabel="Verlauf", ylabel="Score", color="orange")


# In[9]:


glue["Score"].plot.area(title="Flächendiagramm", xlabel="Verlauf", ylabel="Score", color="orange")


# In[10]:


glue["Score"].plot(kind="area", title="Flächendiagramm", xlabel="Verlauf", ylabel="Score", color="orange")


# ## 2. Balkendiagramme

# *Veranschauliche den Score nun in einem Balkendiagramm sortiert nach den einzelnen Jahren. Verwende die Farbe "dunkelblau"*

# In[13]:


glue.sort_values(by="Year").plot.bar(x="Year", y="Score", color="darkblue")


# In[14]:


glue.sort_values(by="Year").plot(kind="barh", x="Year", y="Score", color="darkblue")


# ## 3. Boxplot

# *Verwende nun einen Boxplot jeweils für den Score und aufgeteilt nach:*
# 
# - Model
# 
# - Year
# 
# - Encoder

# In[15]:


glue.boxplot(column=["Score"], by="Model", layout=(1,2))


# In[16]:


glue.boxplot(column=["Score"], by="Year", layout=(1,2))


# In[17]:


glue.boxplot(column=["Score"], by="Encoder", layout=(1,2))


# ## 4. Histogramm

# *Veranschauliche den Score auch in einem Histogramm und setze den bins-Parameter auf 25*
# 
# *Zeichne zwei weitere Histogramme unterteilt nach Model und Year*

# In[20]:


glue["Score"].plot(kind="hist", bins=25, title="Histogramm", xlabel="Score", ylabel="Häufigkeit")


# In[21]:


glue.hist(column="Score", by="Year")


# In[22]:


glue.hist(column="Score", by="Model")


# ## 5. Kuchendiagramm

# *Verwende ein Kuchendiagramm, um den Score nach Models aufzugliedern*

# In[24]:


glue.groupby(by=["Model"]).sum().plot(kind="pie", subplots=True, y="Score")


# In[ ]:




