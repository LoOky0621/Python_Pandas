#!/usr/bin/env python
# coding: utf-8

# # [Pandas Visualisierungen] Balkendiagramm

# In[1]:


import pandas as pd
from matplotlib import pyplot as plt


# In[2]:


umsatz = pd.read_csv("datengrundlage.xls")


# In[4]:


# umsatz


# In[7]:


usa = umsatz[umsatz.Land == "USA"]


# In[8]:


usa.head()


# In[10]:


usa.Stadt.unique()


# In[13]:


phoenix = usa[usa.Stadt == "Phoenix"]


# ### Variante 1

# In[14]:


phoenix.plot.bar(x="Datum", y="Umsatz")


# ### Variante 2

# In[15]:


phoenix.plot(x="Datum", y="Umsatz", kind="bar", color="darkgreen")


# ### Mehrere Balken darstellen

# In[16]:


phoenix[["Datum", "Umsatz", "Kosten"]].plot(kind="bar")


# ### Gestapelte Darstellung

# In[17]:


phoenix[["Datum", "Umsatz", "Kosten"]].plot(kind="bar", stacked=True)


# ### Subplots

# In[19]:


phoenix[["Datum", "Umsatz", "Kosten"]].plot(kind="bar", subplots=True, color={"orange", "darkblue"})


# In[ ]:




