#!/usr/bin/env python
# coding: utf-8

# # [Pandas Visualisierungen] Boxplot

# In[2]:


import pandas as pd
from matplotlib import pyplot as plt


# In[3]:


umsatz = pd.read_csv("datengrundlage.xls")


# In[4]:


umsatz.head()


# ### Describe

# In[6]:


umsatz.describe().transpose()


# ### Lageverteilungsmaße berechnen

# In[7]:


import numpy as np


# In[8]:


print("Mittelwert", np.mean(umsatz.Umsatz))
print("Median", np.median(umsatz.Umsatz))
print("Minimum", np.min(umsatz.Umsatz))
print("Maximum", np.max(umsatz.Umsatz))
print("1. Quartil", np.quantile(umsatz.Umsatz, 0.25))
print("3. Quartil", np.quantile(umsatz.Umsatz, 0.75))


# ## Boxplot

# ### Variante 1

# In[9]:


umsatz.Umsatz.plot(kind="box")


# ### Variante 2

# In[10]:


umsatz.Umsatz.plot.box()


# ### Variante 3

# In[11]:


umsatz.boxplot(column="Umsatz")


# ### Kategorische Aufteilung

# In[12]:


umsatz.boxplot(column="Umsatz", by="Land")


# ### Mehrere Datenreihen

# In[13]:


umsatz.boxplot(column=["Umsatz", "Kosten"])


# ### Aufteilung: Länder

# In[15]:


umsatz.boxplot(column=["Umsatz", "Kosten"], by="Land", layout=(1,2))


# In[ ]:




