#!/usr/bin/env python
# coding: utf-8

# # [Pandas Visualisierungen] Weitere Visualisierungstypen

# In[1]:


import pandas as pd


# In[2]:


umsatz = pd.read_csv("datengrundlage.xls")


# ## Übersicht verwendeter Visualisierungstypen

# - `hist` : **histogram**
# - `box` : **boxplot**
# - `pie` : **pie plot**
# - `scatter` : **scatter plot (DataFrame only)**

# ## Übersicht weiterer Visualisierungstypen

# - `barh` : **horizontal bar plot**
# - `kde` : **Kernel Density Estimation plot**
# - `density` : **same as 'kde'**
# - `area` : **area plot**
# - `hexbin` : **hexbin plot (DataFrame only)**

# ### barh-Plot

# In[5]:


phoenix = umsatz[umsatz.Stadt == "Phoenix"]


# In[6]:


phoenix.plot.bar(x="Datum", y="Umsatz")


# #### Variante 1

# In[8]:


phoenix.plot.barh(x="Datum", y="Umsatz", xlabel="Umsatzzahlen", ylabel="Datumsangaben", title="barh")


# #### Variante 2

# In[9]:


phoenix.plot(kind="barh", x="Datum", y="Umsatz", xlabel="Umsatzzahlen", ylabel="Datumsangaben", title="barh")


# ### KDE-Plot

# - KDE = Kernel Density Estimation 
# - Einsatz von Gaussian Kernels
# - Schätzung einer Wahrscheinlichkeitsdichtefunktion von Zufallsvariablen 

# #### Variante 1

# In[12]:


umsatz.plot.kde(y="Umsatz", bw_method="scott")


# In[13]:


umsatz.plot.kde(y="Umsatz", bw_method="silverman")


# In[14]:


umsatz.plot.kde(y="Umsatz", bw_method=0.1)


# In[16]:


umsatz.plot.kde(y="Umsatz", bw_method=3)


# #### Variante 2

# In[17]:


umsatz.plot(kind="kde", y="Umsatz", bw_method=0.1)


# In[18]:


umsatz[["Kosten", "Umsatz"]].plot(kind="kde", bw_method=0.1)


# ### Density-Plot

# #### Variante 1

# In[19]:


umsatz.plot.density(y="Umsatz", bw_method="scott")


# #### Variante 2

# In[20]:


umsatz[["Kosten", "Umsatz"]].plot(kind="density", bw_method=0.1)


# ### Flächendiagramm

# #### Variante 1

# In[21]:


südkorea = umsatz[umsatz.Land == "Südkorea"]


# In[22]:


südkorea.head()


# In[24]:


from matplotlib import pyplot as plt
plt.figure(figsize=(14, 7))
südkorea.Umsatz.plot(kind="area", color="orange")


# #### Variante 2

# In[27]:


plt.figure(figsize=(14, 7))
axen = plt.gca()
südkorea.plot(y="Umsatz", kind="area", color="orange", ax=axen)
südkorea.plot(y="Kosten", kind="area", color="darkblue", ax=axen)


# In[ ]:




