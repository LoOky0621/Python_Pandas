#!/usr/bin/env python
# coding: utf-8

# # [Pandas Visualisierungen] Punktediagramm

# In[1]:


import pandas as pd


# In[2]:


umsatz = pd.read_csv("datengrundlage.xls")


# In[3]:


umsatz.head()


# ### Punktediagramm

# In[6]:


# pd.DataFrame.plot.scatter?


# ### Variante 1

# In[12]:


umsatz.plot.scatter(x="Kosten", y="Umsatz", s=100, color="orange")


# ### Variante 2

# In[17]:


umsatz.head(1)


# In[18]:


umsatz.plot(kind="scatter", x="Kosten", y="Umsatz", 
            xlabel="Darstellung der Kosten", 
           ylabel="Darstellung der Umsätze", 
           title="Punktediagramm der Kosten und Umsätze", s="Nr")


# In[ ]:




