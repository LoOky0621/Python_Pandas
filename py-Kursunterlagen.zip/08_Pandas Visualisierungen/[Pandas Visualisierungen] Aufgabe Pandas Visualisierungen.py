#!/usr/bin/env python
# coding: utf-8

# # [Pandas Visualisierungen] Weitere Visualisierungstypen

# In[1]:


import pandas as pd
import seaborn as sb


# In[2]:


sb.get_dataset_names()


# ### glue-Datensatz

# **General Language Understanding Evaluation**
# 
# - Natural Language Understanding
# 
# - Plattform zur Bewertung und Analyse von NLP- und NLU-Modellen

# In[3]:


glue = sb.load_dataset("glue")
glue


# ### Sprachverständnisaufgaben

# In[17]:


glue.Task.unique()


# 1. CoLA (Corpus of Linguistic Acceptability)
# 2. MRPC (Microsoft Research Paraphrase Corpus)
# 3. SST-2 (Stanford Sentiment Treebank)
# 4. QQP (Quora Question Pairs)
# 5. STS-B (Semantic Textual Similarity Benchmark)
# 6. MNLI (Multi-Genre Natural Language Inference)
# 7. QNLI (Question NLI)
# 8. WNLI (Winograd NLI)
# 9. RTE (Recognizing Textual Entailment)

# ## 1. Linien- und Flächendiagramm

# *Visualisiere den Score in einem Linien- und Flächendiagramm. Füge Diagrammbeschriftung und Achsenbeschriftungen hinzu. Verwende die Farbe "orange"*

# In[ ]:





# ## 2. Balkendiagramme

# *Veranschauliche den Score nun in einem Balkendiagramm sortiert nach den einzelnen Jahren. Verwende die Farbe "dunkelblau"*

# In[ ]:





# ## 3. Boxplot

# *Verwende nun einen Boxplot jeweils für den Score und aufgeteilt nach:*
# 
# - Model
# 
# - Year
# 
# - Encoder

# In[ ]:





# ## 4. Histogramm

# *Veranschauliche den Score auch in einem Histogramm und setze den bins-Parameter auf 25*
# 
# *Zeichne zwei weitere Histogramme unterteilt nach Model und Year*

# In[ ]:





# ## 5. Kuchendiagramm

# *Verwende ein Kuchendiagramm, um den Score nach Models aufzugliedern*

# In[ ]:




