#!/usr/bin/env python
# coding: utf-8

# # [Pandas Visualisierungen] Kuchendiagramm

# In[2]:


import pandas as pd
from matplotlib import pyplot as plt


# In[3]:


umsatz = pd.read_csv("datengrundlage.xls")


# ## Kuchendiagramm darstellen

# ### Gruppierung nach Land

# In[6]:


umsatz.groupby(by=["Land"]).sum().plot(kind="pie", 
                                       subplots=True, 
                                       y="Umsatz", 
                                      colors=["red", "blue", "green", "yellow", "darkblue", "black"])


# ### Visualisierung

# In[10]:


umsatz[["Umsatz", "Land"]].groupby(["Land"]).sum().plot(kind="pie", subplots=True, startangle=90)


# ### Kosten darstellen

# In[13]:


umsatz[["Kosten", "Jahr"]].groupby(["Jahr"]).sum()


# In[14]:


umsatz.groupby(["Jahr"]).sum().plot(kind="pie", subplots=True, y="Kosten")


# In[ ]:




