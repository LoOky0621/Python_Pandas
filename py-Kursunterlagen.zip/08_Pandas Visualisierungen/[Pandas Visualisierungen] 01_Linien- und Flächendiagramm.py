#!/usr/bin/env python
# coding: utf-8

# # [Pandas Visualisierungen] Linien- und Flächendiagramm

# In[1]:


import pandas as pd
from matplotlib import pyplot as plt


# In[2]:


umsatz = pd.read_csv("datengrundlage.xls")


# ### Plot-Funktion

# In[4]:


# pd.DataFrame.plot?


# In[6]:


umsatz.plot()


# In[9]:


v = umsatz["Umsatz"].plot()


# In[10]:


type(v)


# #### Alternative Schreibweise

# In[11]:


umsatz.plot(kind="line")


# ### Einzelne Spalten

# #### Variante 1

# In[12]:


umsatz.Umsatz.plot()


# #### Variante 2

# In[13]:


umsatz["Umsatz"].plot()


# ### Filterung Daten

# In[18]:


südkorea = umsatz[umsatz.Land == "Südkorea"]


# In[24]:


plt.figure(figsize=(14, 7))
südkorea.Umsatz.plot(kind="line", color="orange")


# ### Mehrere Linien

# #### Variante 1

# In[25]:


südkorea[["Umsatz", "Kosten"]].plot(subplots=True)


# #### Variante 2

# In[27]:


plt.figure(figsize=(14, 5))
axen = plt.gca()
südkorea.plot(y="Umsatz", ax=axen);
südkorea.plot(y="Kosten", ax=axen)


# In[ ]:




