#!/usr/bin/env python
# coding: utf-8

# # [Datenverarbeitung] Eingebaute Datensätze mit Seaborn

# In[1]:


import pandas as pd


# ## 1) Seaborn Datensätze

# In[3]:


import seaborn as sb


# ### 1.1) Datensätze anzeigen

# In[5]:


sb.get_dataset_names()


# ### 1.2) Datensätze laden

# In[7]:


flights = sb.load_dataset("flights")


# In[8]:


flights.head(3)


# ### 1.3) Beispiel: Datenauswertung

# In[9]:


sb.lineplot(x="year", y="passengers", data=flights)


# In[10]:


penguins = sb.load_dataset("penguins")


# In[11]:


penguins.head()


# In[13]:


sb.boxplot(x=penguins.island, y=penguins.body_mass_g)
sb.swarmplot(x=penguins.island, y=penguins.body_mass_g)


# ## 2) Statsmodels Datensätze

# ### 2.1) Datensätze anzeigen

# In[16]:


#!pip install statsmodels
#conda install statsmodels
from statsmodels import datasets


# In[18]:


# dir(datasets)


# In[22]:


datasets.copper.DESCRSHORT


# In[23]:


datasets.copper.DESCRLONG


# ### 2.2) Datensätze laden

# In[24]:


copper = datasets.copper.load_pandas().data


# ## 3) Sklearn Datensätze

# ### 3.1) Datensätze anzeigen

# In[26]:


from sklearn import datasets
#dir(datasets)


# ### 3.2) Datensätze laden

# In[28]:


datasets.load_boston().DESCR


# In[ ]:




