#!/usr/bin/env python
# coding: utf-8

# # [Datenverarbeitung] Einträge verwalten

# In[1]:


import pandas as pd


# In[45]:


# Umsatz, Marktkapitalisierung, Ergebnis
tech = pd.DataFrame({'AAPL': [395, 2390, 100], 
                   'GOOG': [280, 1240, 60], 
                  'AMZ' : [514, 960, 14]}, 
                   index = ["umsatz", "marktkapitalisierung", "ergebnis"])


# In[46]:


tech


# ## insert()-Funktion

# In[47]:


tech.insert(1, "MSFT", [199, 1960, 73])


# In[48]:


tech.insert(1, "MSFT", [199, 1960, 73], allow_duplicates= True)


# In[19]:


tech


# ### Ersetzungen durchführen

# In[27]:


tech


# In[26]:


# tech.rename(columns = {tech.columns[1] : "MSFT2"})


# In[30]:


tech.transpose().rename(index = {"MSFT" : "MSFT2"})


# In[35]:


tech.columns = ["AAPL", "MSFT", "MSFT2", "GOOG", "AMZ"]


# In[36]:


tech


# In[37]:


tech["IBM"] = [61, 105, 8]


# In[38]:


tech


# In[39]:


tech.MSFT2 = tech.IBM


# ### Spalte entfernen

# In[40]:


tech


# In[41]:


del tech["IBM"]


# In[42]:


tech


# In[43]:


tech.columns = ["AAPL", "MSFT", "IBM", "GOOG", "AMZ"]


# In[44]:


tech


# ### Alternative: replace()-Funktion

# In[49]:


tech


# In[50]:


tech.columns = ["AAPL", "MSFT", "MSFT2", "GOOG", "AMZ"]


# In[51]:


tech


# In[53]:


tech["IBM"] = [61, 105, 8]


# In[54]:


tech["MSFT2"] = tech.IBM.replace([199, 1960, 73], [61, 105, 8])


# In[55]:


tech


# In[56]:


del tech["IBM"]


# In[57]:


tech.columns = ["AAPL", "MSFT", "IBM", "GOOG", "AMZ"]


# In[58]:


tech


# In[ ]:




