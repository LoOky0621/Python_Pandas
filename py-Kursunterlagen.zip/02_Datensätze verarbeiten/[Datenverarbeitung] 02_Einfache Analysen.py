#!/usr/bin/env python
# coding: utf-8

# # [Datenverarbeitung] Einfache Analysen

# In[2]:


import pandas as pd


# ### CSV-Dateien importieren

# In[2]:


umsatz = pd.read_csv("datengrundlage.csv")


# ### Excel-Tabellen importieren

# In[3]:


umsatz = pd.read_excel("datengrundlage.xlsx")


# In[5]:


print(umsatz)


# In[4]:


umsatz


# ### head

# In[8]:


umsatz.head(10)


# ### tail

# In[9]:


umsatz.tail(3)


# ### info

# In[10]:


umsatz.info()


# ### describe

# In[12]:


umsatz.describe().transpose()


# ### columns

# In[13]:


umsatz.columns


# ### values

# In[14]:


umsatz.values


# ### dtypes

# In[15]:


umsatz.dtypes


# ### Anzahl Zeilen

# In[16]:


len(umsatz)


# ### Anzahl Spalten

# In[17]:


len(umsatz.columns)


# ### shape

# In[19]:


umsatz.shape


# ### sample

# In[23]:


umsatz.sample(7)


# In[24]:


umsatz.sample(frac = 0.004)


# In[26]:


print(round(0.004*len(umsatz)))


# In[ ]:




