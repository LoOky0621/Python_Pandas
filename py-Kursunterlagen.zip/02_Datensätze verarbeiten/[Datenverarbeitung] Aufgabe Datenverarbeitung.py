#!/usr/bin/env python
# coding: utf-8

# # [Datenverarbeitung] Aufgabe Datenverarbeitung

# In[1]:


import pandas as pd


# ## 1) Daten importieren

# *Gegeben sei die Excel-Datei aufgabe_datenverarbeitung.xlsx mit fiktiven Absatzzahlen eines Unternehmens. Lese die Datei mit Pandas ein*

# In[2]:





# ## 2) Analysen

# ### 2.1) Einträge untersuchen

# *Verwende sowohl eine Funktion, um die ersten 5 als auch die letzten 5 Einträge anzuzeigen*

# In[ ]:





# ### 2.2) Datensatz erkunden

# *Wie viele Einträge umfasst der Datensatz? Wie viele Spalten liegen vor?*

# In[ ]:





# ### 2.3) Lageverteilung

# *Verwende eine geeignete Funktion, um die Lageverteilung des Absatzes und der Kosten zu analysieren*

# In[ ]:





# ### 2.4) Zufällige Werte auswählen

# *Verwende eine Funktion, um nun 5 zufällige Werte zu generieren. Aus welchen Städten stammen die Absätze?*

# In[ ]:





# ## 3) Daten exportieren

# *Speichere den Datensatz nun sowohl als .csv- als auch als -xlsx-Datei ab*

# In[ ]:





# ## 4) Umbenennungen

# *Benenne nun die Spalte "Absatz" um zu "Verkaufsmenge" und "Stadt" zu "Region"*

# In[ ]:





# ## 5) Indizierung

# ### 5.1) Index setzen

# *Setze nun das Datum als Index*

# In[ ]:





# ### 5.2) Index zurücksetzen

# *Setze den Index nun wieder zurück*

# In[ ]:





# ## 6) Einträge verwalten

# *Entferne nun die Spalte "Kunde"*

# In[ ]:





# *Überprüfe nun über alle Einträge hinweg ob die Stadt München vorkommt. Schreibe das Ergebnis als neue Spalte in den Datensatz*

# In[ ]:




