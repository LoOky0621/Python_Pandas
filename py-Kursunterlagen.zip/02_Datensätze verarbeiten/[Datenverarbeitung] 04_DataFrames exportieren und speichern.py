#!/usr/bin/env python
# coding: utf-8

# # [Datenverarbeitung] DataFrames exportieren

# In[1]:


import pandas as pd


# In[2]:


umsatz = pd.read_csv("datengrundlage.csv")


# In[3]:


umsatz.head()


# In[8]:


umsatz_stadt_land = umsatz[["Land", "Stadt", "Umsatz"]]


# In[10]:


# umsatz_stadt_land


# ### CSV exportieren

# In[6]:


# pd.DataFrame.to_csv?


# In[11]:


umsatz_stadt_land.to_csv("umsatz_stadt_land.csv")


# ### Excel exportieren

# In[ ]:


# pd.DataFrame.to_excel?


# In[12]:


umsatz_stadt_land.to_excel("umsatz_stadt_land.xlsx")


# ### auf Laufwerk exportieren 

# In[13]:


umsatz_stadt_land.to_excel(r"C:\Users\Fabio\OneDrive\Desktop\umsatz_stadt_land.xlsx")


# In[ ]:




