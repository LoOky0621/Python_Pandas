#!/usr/bin/env python
# coding: utf-8

# # [Datenverarbeitung] Umbenennungen

# In[1]:


import pandas as pd
umsatz = pd.read_csv("datengrundlage.csv")


# In[2]:


umsatz.head(3)


# ## Umbenennungen

# ### rename

# In[6]:


umsatz = umsatz.rename(columns = {"Land":"Länder", "Stadt":"Städte"})


# In[8]:


# umsatz


# ### rename_axis

# In[11]:


umsatz.rename_axis("ID", axis="columns")


# ### rename(index=["old":"new"])

# In[15]:


data = pd.DataFrame(data = {"airbus" : [59, 5.2, 101, 134267], 
                    "boeing" : [66, -3.5, 114, 156000]}, 
                    index = ["umsatz", "ergebnis", "börsenwert", "mitarbeiter"]).transpose()


# In[16]:


data.index


# In[17]:


data.rename(index = {"airbus":"Airbus", "boeing":"Boeing"})


# In[18]:


data2 = pd.DataFrame(data = {"airbus" : [59, 5.2, 101, 134267], 
                    "boeing" : [66, -3.5, 114, 156000]}, 
                    index = ["umsatz", "ergebnis", "börsenwert", "mitarbeiter"])


# In[19]:


data2.index


# In[21]:


data2.rename(index = {"umsatz":"Umsatz", "ergebnis":"Ergebnis", 
                     "börsenwert":"Marktkapitalisierung", "mitarbeiter":"Mitarbeiter"})


# In[ ]:




