#!/usr/bin/env python
# coding: utf-8

# # [Indexing] Indizes mit Pandas

# In[1]:


import pandas as pd


# In[15]:


umsatz = pd.read_excel("datengrundlage.xlsx", index_col = None)
umsatz.head(3)


# ## Indizes

# ### set_index: "Nr."

# In[12]:


get_ipython().run_line_magic('pinfo', 'pd.DataFrame.index')


# In[13]:


umsatz.index


# In[16]:


# umsatz.set_index(["Nr"])


# ### del: Spalten Löschen

# In[17]:


del umsatz["Nr"]


# In[18]:


umsatz.head(2)


# ### set_index: "Datum"

# In[19]:


umsatz.set_index(["Datum"])


# ### reset_index()

# In[21]:


umsatz.reset_index()


# In[ ]:




