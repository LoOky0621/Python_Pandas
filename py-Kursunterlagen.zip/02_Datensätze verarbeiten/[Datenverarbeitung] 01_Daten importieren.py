#!/usr/bin/env python
# coding: utf-8

# # [Datenverarbeitung] Daten importieren

# In[1]:


import pandas as pd


# In[4]:


pd.read_csv("textdatei1.txt")


# In[7]:


textdatei = pd.read_csv("textdatei2.txt", sep=",")


# ### CSV-Datei importieren

# In[8]:


umsatz = pd.read_csv("datengrundlage.csv")


# In[9]:


umsatz.head()


# ### Excel-Datei importieren

# In[11]:


umsatz = pd.read_excel("datengrundlage.xlsx")


# In[12]:


umsatz.head()


# In[ ]:




