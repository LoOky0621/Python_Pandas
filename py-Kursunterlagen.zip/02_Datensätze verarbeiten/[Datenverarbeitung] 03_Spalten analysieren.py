#!/usr/bin/env python
# coding: utf-8

# # [Datenverarbeitung] Spalten analysieren

# In[2]:


import pandas as pd


# ### CSV-Dateien importieren

# In[3]:


umsatz = pd.read_csv("datengrundlage.csv")


# In[4]:


umsatz.head()


# In[6]:


print(umsatz)


# ### Einzelne Spalte auswählen

# #### Variante 1

# In[5]:


umsatz.Stadt


# In[8]:


print(type(umsatz))
print(type(umsatz.Stadt))


# #### Variante 2

# In[9]:


umsatz["Stadt"]


# ### Shape

# In[10]:


umsatz["Stadt"].shape


# In[11]:


len(umsatz)


# ### Unique

# In[13]:


umsatz.Stadt.unique()


# ### nunique

# In[15]:


umsatz.Stadt.nunique()


# ### nlargest

# In[17]:


umsatz.nlargest(7, "Kosten")


# ### Mehrere Spalten auswählen

# In[21]:


umsatz[["Stadt", "Land"]]


# In[20]:


umsatz[["Land", "Stadt"]]


# In[ ]:




