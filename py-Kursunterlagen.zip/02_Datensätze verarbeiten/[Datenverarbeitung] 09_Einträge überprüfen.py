#!/usr/bin/env python
# coding: utf-8

# # [Datenverarbeitung] Einträge überprüfen

# In[5]:


import pandas as pd


# In[9]:


# Branche, Umsatz, Marktkapitalisierung, Ergebnis
tech = pd.DataFrame({'AAPL': ["Hardware", 395, 2390, 100], 
                   'GOOG': ["Advertisement", 280, 1240, 60], 
                  'AMZ' : ["E-Commerce/Cloud", 514, 960, 14]}, 
                   index = ["branche", "umsatz", "börsenwert", "ergebnis"])


# In[10]:


tech


# ### Gibt es `ein` Hardware-Unternehmen?

# In[12]:


# pd.DataFrame.isin?


# In[13]:


tech.isin(["Hardware"])


# ### Gibt es `kein` Hardware-Unternehmen?

# In[14]:


~ tech.isin(["Hardware"])


# ### Umsatzdatensatz

# In[15]:


umsatz = pd.read_csv("datengrundlage.csv")


# In[16]:


umsatz.head(3)


# In[18]:


umsatz.Land.isin(["China"])


# In[20]:


umsatz.Land.isin(["China", "USA", "Südafrika"])


# In[ ]:




