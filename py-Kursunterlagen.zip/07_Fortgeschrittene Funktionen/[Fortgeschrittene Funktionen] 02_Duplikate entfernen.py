#!/usr/bin/env python
# coding: utf-8

# # [Fortgeschrittene Funktionen] Duplikate entfernen

# In[1]:


import pandas as pd


# ### Datengrundlage

# In[2]:


stocks = pd.DataFrame({
    'firma': ['Coke', 'Pepsi', 'Monster', 'Nestle', 'Unilever', "Coke"],
    'branche': ['drinks', 'food-beverage', 'drinks', 'food-beverage', 'consumer goods', "drinks"],
    'kgv': [29, 28, 45, 31, 16, 29]
})


# In[3]:


stocks


# ## Duplikate verwalten

# In[5]:


stocks.duplicated()


# In[6]:


stocks.drop_duplicates()


# In[8]:


stocks


# In[7]:


stocks.drop_duplicates(subset=["branche"])


# In[9]:


stocks.drop_duplicates(subset=["branche"], keep="first")


# In[10]:


stocks.drop_duplicates(subset=["branche"], keep="last")


# In[ ]:




