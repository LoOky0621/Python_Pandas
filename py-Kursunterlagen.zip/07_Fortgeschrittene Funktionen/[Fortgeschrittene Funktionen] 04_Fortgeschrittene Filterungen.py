#!/usr/bin/env python
# coding: utf-8

# # [Fortgeschrittene Funktionen] Fortgeschrittene Filterungen

# In[1]:


import pandas as pd
umsatz = pd.read_csv("datengrundlage.xls")


# ## between-Filterung

# ### Numerische Filterung

# In[3]:


umsatz.Umsatz.between(5000, 6000)


# In[7]:


umsatz[(umsatz.Umsatz <= 6000) & (umsatz.Umsatz >= 5000)]


# In[4]:


umsatz[umsatz.Umsatz.between(5000, 6000)]


# In[28]:


umsatz.Umsatz.between(umsatz.Umsatz.mean(), umsatz.Umsatz.max())


# In[29]:


umsatz[umsatz.Umsatz.between(umsatz.Umsatz.mean(), umsatz.Umsatz.max())]


# ### Alphabetische Filterung

# In[9]:


umsatz.Stadt.between("V", "Z")


# In[10]:


umsatz[umsatz.Stadt.between("V", "Z")]


# In[13]:


umsatz[umsatz.Land.between("M", "S")]


# ## where-Filterung

# In[15]:


umsatz.Umsatz > 6500


# In[16]:


umsatz[umsatz.Umsatz > 6500]


# In[20]:


umsatz.Umsatz.where(umsatz.Umsatz > 6500)


# In[18]:


type(umsatz.Umsatz.where(umsatz.Umsatz > 6500))


# In[22]:


umsatz.Umsatz.where(umsatz.Umsatz > 6500)


# In[23]:


umsatz.Umsatz.where(umsatz.Umsatz > 6500).fillna(0)


# In[24]:


umsatz.Umsatz.where(umsatz.Umsatz > 6500).fillna(0) != 0


# In[25]:


umsatz[umsatz.Umsatz.where(umsatz.Umsatz > 6500).fillna(0) != 0]


# In[26]:


umsatz.Umsatz.where(umsatz.Umsatz > umsatz.Umsatz.mean())


# In[27]:


umsatz.Umsatz.where(umsatz.Umsatz > umsatz.Umsatz.median())


# ## idxmin

# In[30]:


umsatz.Kosten.min()


# In[33]:


umsatz.Kosten.idxmin()


# In[35]:


umsatz.iloc[963:970, ]


# ## idxmax

# In[31]:


umsatz.Kosten.max()


# In[34]:


umsatz.Kosten.idxmax()


# In[36]:


umsatz.iloc[1005:1010, ]


# In[38]:


umsatz.loc[:, ["Umsatz", "Kosten"]].idxmin()


# In[39]:


umsatz.loc[:, ["Umsatz", "Kosten"]].idxmax()


# In[40]:


umsatz.iloc[[umsatz.Umsatz.idxmin(), umsatz.Umsatz.idxmax()]]


# In[ ]:




