#!/usr/bin/env python
# coding: utf-8

# # [Fortgeschrittene Funktionen] Fortgeschrittene Analysen

# In[1]:


import pandas as pd
umsatz = pd.read_csv("datengrundlage.xls")


# In[2]:


umsatz.head(3)


# ### dtypes

# In[3]:


umsatz.dtypes


# ### to_datetime

# In[6]:


umsatz.Datum = pd.to_datetime(umsatz.Datum)


# In[7]:


umsatz.dtypes


# ### memory_usage

# In[8]:


umsatz.memory_usage(deep=True)


# ### value_counts

# In[12]:


print(umsatz.Land.unique())
print(umsatz.Stadt.unique())


# In[14]:


print(umsatz.Land.value_counts())
print(umsatz.Stadt.value_counts())


# ### describe und transpose

# In[17]:


umsatz.describe(percentiles=[0.1, 0.9]).transpose()


# In[18]:


umsatz.describe(percentiles=[0.1, 0.9]).T


# ### convert_dtypes

# In[19]:


print(umsatz.dtypes)


# In[21]:


umsatz.convert_dtypes().dtypes


# In[ ]:




