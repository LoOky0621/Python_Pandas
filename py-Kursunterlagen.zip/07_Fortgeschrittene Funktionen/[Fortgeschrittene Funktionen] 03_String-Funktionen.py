#!/usr/bin/env python
# coding: utf-8

# # [Fortgeschrittene Funktionen] String-Funktionen

# > - len
# 
# > - cat
# 
# > - upper()
# 
# > - lower()
# 
# > - isupper()
# 
# > - contains()
# 
# > - replace()
# 
# > - split()
# 
# > - find()
# 
# > - findall()
# 
# > - startswith()
# 
# > - endswith()

# In[11]:


# type("Pandas")
# type('Pandas')


# In[48]:


import pandas as pd


# In[49]:


umsatz = pd.read_csv("datengrundlage.xls")


# In[14]:


umsatz.head(3)


# ### len

# In[15]:


len(umsatz.Land)


# In[17]:


len(umsatz.columns)


# In[19]:


umsatz.Land


# In[18]:


umsatz.Land.str.len()


# ### cat

# In[21]:


type(umsatz.Land.str.cat())


# In[22]:


# umsatz.Land.str.cat()


# ### lower

# In[24]:


umsatz.Land


# In[23]:


umsatz.Land.str.lower()


# In[32]:


lower = umsatz.Land.str.lower()


# ### upper

# In[28]:


upper = umsatz.Land.str.upper()


# ### isupper

# In[26]:


umsatz.Stadt.str.isupper()


# In[31]:


upper.str.isupper()


# In[33]:


lower.str.isupper()


# ### islower

# In[27]:


umsatz.Stadt.str.islower()


# In[35]:


upper.str.islower()


# In[34]:


lower.str.islower()


# ### contains

# In[39]:


# umsatz["Logistik-Code"]


# In[40]:


umsatz[umsatz["Logistik-Code"].str.contains("6-")]


# In[41]:


len(umsatz[umsatz["Logistik-Code"].str.contains("6-")])


# In[42]:


umsatz


# In[43]:


print(185/1380)


# ### replace

# In[46]:


umsatz = umsatz.Land.str.replace("Deutschland", "DE")


# In[47]:


umsatz


# ### split

# In[51]:


umsatz.Kunde.str.split("-")


# ### find

# In[53]:


umsatz.Stadt


# In[52]:


umsatz.Stadt.str.find("a")


# ### findall

# In[55]:


umsatz.Kunde


# In[54]:


umsatz.Kunde.str.findall("C-1")


# In[56]:


umsatz.Kunde.str.findall("C-1*")


# ### startswith

# In[57]:


umsatz.Kunde.str.startswith("C-1")


# In[58]:


umsatz[umsatz.Kunde.str.startswith("C-1")]


# ### endswith

# In[60]:


umsatz.Kunde.str.endswith("4")


# In[61]:


umsatz[umsatz.Kunde.str.endswith("4")]


# In[ ]:




