#!/usr/bin/env python
# coding: utf-8

# # [Sortierungen] sort_values

# In[1]:


import pandas as pd
umsatz = pd.read_csv("datengrundlage.xls")


# In[3]:


umsatz.head()


# In[6]:


umsatz.describe().transpose()


# In[4]:


get_ipython().run_line_magic('pinfo', 'pd.DataFrame.sort_values')


# ### Aufsteigende Sortierung

# In[8]:


umsatz.Umsatz.sort_values()


# In[9]:


umsatz.Umsatz.sort_values(ascending=True)


# ### Absteigende Sortierung

# In[10]:


umsatz.Umsatz.sort_values(ascending=False)


# ### Alternative

# In[12]:


umsatz.sort_values(by = "Umsatz", ascending = False)["Umsatz"]


# In[14]:


umsatz.sort_values(by = ["Umsatz"], ascending = True)["Umsatz"]


# ### Sortieren nach Kategorien

# In[16]:


umsatz.sort_values(by="Land")


# ### Nach mehreren Kategorien sortieren

# In[18]:


umsatz.Stadt.unique()


# In[17]:


umsatz.sort_values(by=["Land", "Stadt"])


# In[20]:


umsatz.sort_values(by=["Umsatz", "Kosten"], ascending=True)


# In[ ]:




