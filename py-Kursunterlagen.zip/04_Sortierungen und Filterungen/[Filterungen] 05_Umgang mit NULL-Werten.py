#!/usr/bin/env python
# coding: utf-8

# # [Filterungen] Umgang mit NULL-Werten

# In[1]:


import pandas as pd
import numpy as np


# ### Anwendungsbeispiel

# In[16]:


# Sitz, Umsatz, Ergebnis, Mitarbeiter
sports = pd.DataFrame({"NIKE" : ["USA", np.NaN, 7, 80000], 
             "ADI" : ["DE", 22, 0.5, np.NaN], 
             "PUMA" : ["DE", np.NaN, np.NaN, 18000]}, 
                      index=["Sitz", "Umsatz", "Ergebnis", "Mitarbeiter"])


# ## Umgang mit NULL

# In[9]:


sports.isnull()


# In[10]:


sports


# In[13]:


print(sports["NIKE"].isnull().sum())
print(sports["ADI"].isnull().sum())
print(sports["PUMA"].isnull().sum())


# ### fillna()-Methode

# In[14]:


sports.fillna(0, inplace=True)


# In[15]:


sports


# In[17]:


sports.fillna("Keine Angabe", inplace=True)


# In[18]:


sports


# In[ ]:




