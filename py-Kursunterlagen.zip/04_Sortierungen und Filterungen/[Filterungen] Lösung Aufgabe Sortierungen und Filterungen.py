#!/usr/bin/env python
# coding: utf-8

# # [Filterungen] Lösung Aufgabe Sortierungen und Filterungen

# In[1]:


import pandas as pd
import seaborn as sb


# ### Datengrundlage: healthexp

# In[2]:


healthexp = sb.load_dataset("healthexp")


# In[5]:


healthexp.Country.unique()


# In[3]:


healthexp.head()


# In[4]:


healthexp.tail()


# ## 1) Sortierung

# ### 1.1) Auf- und absteigende Sortierung

# *Sortiere zunächst die Lebenserwartung auf- und absteigend*

# In[9]:


life_exp_asc = healthexp.Life_Expectancy.sort_values(ascending=True)


# In[10]:


life_exp_desc = healthexp.Life_Expectancy.sort_values(ascending=False)


# In[11]:


life_exp_asc


# In[12]:


life_exp_desc


# ### 1.2) Kategorische Sortierung

# *Sortiere nun zunächst nach der Kategorie Land und dann nach Jahr durch eine Codezeile*

# In[15]:


healthexp.sort_values(by=["Country", "Year"], ascending=True)


# ## 2) Ranking

# *Berechne nun die Ränge aufsteigend von "Spending_USD". Sortiere anschließend die Ergebnisse absteigend*

# In[18]:


healthexp["rank_asc"] = healthexp.Spending_USD.rank(ascending=True)


# In[20]:


healthexp.rank_asc.sort_values(ascending=False)


# ## 3) Filter-Funktion

# ### 3.1) Kategorische Filterungen

# *Filtere zunächst nach den Jahren 2000-2015*

# #### Möglichkeit 1

# In[26]:


healthexp_new = healthexp[(healthexp.Year >= 2000) & (healthexp.Year <= 2015)]


# #### Möglichkeit 2

# In[27]:


healthexp_new = healthexp[(healthexp["Year"] >= 2000) & (healthexp["Year"] <= 2015)]


# In[30]:


healthexp_new = healthexp[healthexp["Year"] >= 2000][(healthexp["Year"] <= 2015)]


# In[31]:


healthexp_new


# #### Möglichkeit 3

# In[28]:


healthexp_new = healthexp[(healthexp["Year"] > 1999) & (healthexp["Year"] < 2016)]


# In[29]:


healthexp_new


# ### 3.2) Filterung durch Berechnung

# *Berechne nun die durchschnittliche Lebenserwartung über den Median in diesem Zeitintervall. Filtere nun alle Daten, bei denen die Lebenserwartung über dem Median liegt*

# In[34]:


healthexp_new.Life_Expectancy.median()


# In[40]:


healthexp_new[healthexp_new.Life_Expectancy > healthexp_new.Life_Expectancy.median()]


# ## 4) query-Funktion

# *Betrachte nun ausschließlich die Jahre 2016 bis 2020. Berechne anschließend die neue Spalte "Spending_USD_new", welche die Variable "Spending_USD" durch die Zahl 60 dividiert. Verwende nun die query()-Funktion, um zu zählen bei wie vielen Einträgen Spending_USD_new größer ist als Life_Expectancy*

# In[47]:


healthexp_2016_2020 = healthexp[healthexp.Year > 2015]


# In[49]:


healthexp_2016_2020.head(1)


# In[51]:


healthexp_2016_2020["Spending_USD_new"] = healthexp_2016_2020["Spending_USD"] / 60


# In[55]:


print(len(healthexp_2016_2020.query("Spending_USD_new > Life_Expectancy")))
print(len(healthexp_2016_2020.query("Spending_USD_new < Life_Expectancy")))


# In[ ]:




