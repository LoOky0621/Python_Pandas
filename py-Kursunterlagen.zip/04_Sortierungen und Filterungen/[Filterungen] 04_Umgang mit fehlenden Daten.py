#!/usr/bin/env python
# coding: utf-8

# # [Filterungen] Umgang mit fehlenden Daten

# In[18]:


import pandas as pd


# In[19]:


umsatz = pd.read_csv("fehlende_Daten.csv")


# In[20]:


umsatz.head()


# In[5]:


umsatz.isna()


# In[6]:


umsatz.notna()


# In[10]:


umsatz[umsatz.Umsatz.isna()]


# In[11]:


umsatz[umsatz.Kosten.isna()]


# In[12]:


umsatz[umsatz.Umsatz.notna()]


# In[13]:


umsatz[umsatz.Kosten.notna()]


# In[15]:


print(len(umsatz[umsatz.Umsatz.isna()]))
print(len(umsatz[umsatz.Umsatz.notna()]))

print(len(umsatz[umsatz.Kosten.isna()]))
print(len(umsatz[umsatz.Kosten.notna()]))


# ### Befüllung von leeren Einträgen

# #### Numerische Null

# In[16]:


umsatz.Umsatz.fillna(0, inplace=True)


# In[17]:


umsatz


# #### Arithmetisches Mittel

# In[21]:


umsatz.Umsatz.fillna(umsatz.Umsatz.mean(), inplace=True)


# In[23]:


umsatz.Umsatz.mean()


# In[22]:


umsatz


# In[ ]:




