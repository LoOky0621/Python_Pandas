#!/usr/bin/env python
# coding: utf-8

# # [Filterungen] query-Funktion

# In[2]:


import pandas as pd
umsatz = pd.read_csv("datengrundlage.xls")


# *Wie viele Einträge gibt es, bei denen die Kosten größer sind als die Umsätze?*

# In[6]:


umsatz[umsatz.Umsatz < umsatz.Kosten]


# In[7]:


print(len(umsatz[umsatz.Umsatz < umsatz.Kosten]))


# ## query()-Funktion in der Anwendung

# In[10]:


umsatz.query("Umsatz < Kosten")


# ### Weiteres Anwendungsbeispiel

# In[14]:


umsatz["umsatz_over_avg"] = umsatz.Umsatz > umsatz.Umsatz.mean()


# In[16]:


umsatz["kosten_over_avg"] = umsatz.Kosten > umsatz.Kosten.mean()


# In[17]:


umsatz.query("umsatz_over_avg == `kosten_over_avg`")


# In[18]:


umsatz.query("umsatz_over_avg != `kosten_over_avg`")


# In[ ]:




