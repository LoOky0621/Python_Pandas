#!/usr/bin/env python
# coding: utf-8

# # [Filterungen] Filterungen über DataFrames Schreibweisen

# In[1]:


import pandas as pd
umsatz = pd.read_csv("datengrundlage.xls")


# In[2]:


umsatz.head(3)


# ## Numerische Filterungen

# ### Vergleichsoperatoren

# > **"==": entspricht**
# 
# > **"!=": ungleich**
# 
# > **">": größer**
# 
# > **"<": kleiner**
# 
# > **">=": größer gleich**
# 
# > **"<=": kleiner gleich**

# In[5]:


umsatz[umsatz.Umsatz > 7000]


# In[6]:


print(len(umsatz))
print(len(umsatz[umsatz.Umsatz > 7000]))


# In[ ]:


umsatz[umsatz.Umsatz > umsatz.Umsatz.mean()]
xquer = umsatz.Umsatz.mean()
# umsatz[umsatz.Umsatz > xquer]


# In[11]:


umsatz[umsatz.Umsatz > umsatz.Umsatz.median()]
med = umsatz.Umsatz.median()
# umsatz[umsatz.Umsatz > med]


# ## Kategorische Filterungen

# In[16]:


deutschland = umsatz[umsatz.Land == "Deutschland"]


# In[17]:


deutschland.head(3)


# In[18]:


stuttgart = umsatz[umsatz.Stadt == "Stuttgart"]


# ## Mehrere Filterkriterien

# ### Logisches UND

# In[21]:


umsatz.head(4)


# In[22]:


xquer


# In[20]:


(umsatz.Land == "China") & (umsatz.Umsatz > umsatz.Umsatz.mean())


# In[23]:


(umsatz.Land != "China") & (umsatz.Umsatz > umsatz.Umsatz.mean())


# ### Logisches ODER

# In[24]:


(umsatz.Land != "China") | (umsatz.Umsatz > umsatz.Umsatz.mean())


# In[27]:


china_usa = umsatz[(umsatz.Land == "China") | (umsatz.Land == "USA")]


# In[28]:


china_usa.head()


# In[ ]:




