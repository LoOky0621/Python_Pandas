#!/usr/bin/env python
# coding: utf-8

# # [Filterungen] filter-Funktion

# In[2]:


import pandas as pd
umsatz = pd.read_csv("datengrundlage.xls")


# ## Filter-Funktion

# In[4]:


# pd.DataFrame.filter?


# ### Übersicht Parameter

# > - **item** – exaktes Attribut
# > - **like** – Bezeichnung der Achse
# > - **regex** – regular expression
# 
# **axis** – {0 or ‘index’, 1 or ‘columns’, None}, default None. When not specified it used

# ### 1. items

# In[6]:


# umsatz


# In[7]:


umsatz.filter(items=["Kunde"], axis=1)


# In[10]:


umsatz.filter(items=["Stadt", "Umsatz"], axis=1)


# In[13]:


umsatz.set_index("Datum").filter(items=["1/2/2025"], axis=0)


# In[14]:


umsatz.set_index("Datum").filter(items=["1/2/2025", "1/7/2025"], axis=0)


# ### 2. like

# In[16]:


umsatz.filter(like="U", axis=1)


# In[17]:


umsatz.filter(like="e")


# In[18]:


umsatz.filter(like="2", axis=0)


# ### 3. regex

# In[19]:


umsatz.filter(regex="e", axis=1)


# In[20]:


umsatz.filter(regex="e$", axis=1)


# In[23]:


umsatz.set_index("Datum").filter(regex="12/2025$", axis=0)


# In[ ]:




