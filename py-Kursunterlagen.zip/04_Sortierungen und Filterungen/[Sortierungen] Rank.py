#!/usr/bin/env python
# coding: utf-8

# # [Sortierungen] Ränge erstellen über rank

# In[3]:


import pandas as pd
umsatz = pd.read_csv("datengrundlage.xls")


# In[4]:


get_ipython().run_line_magic('pinfo', 'pd.DataFrame.rank')


# In[6]:


umsatz_stadt = umsatz.loc[:, ["Umsatz", "Stadt"]]


# In[10]:


umsatz_stadt["rank_asc"] = umsatz_stadt.Umsatz.rank(ascending = True)


# In[12]:


umsatz_stadt["rank_desc"] = umsatz_stadt.Umsatz.rank(ascending = False)


# In[14]:


umsatz_stadt.sort_values(by="rank_asc")


# In[20]:


umsatz_stadt.sample(n=len(umsatz_stadt))


# In[ ]:




